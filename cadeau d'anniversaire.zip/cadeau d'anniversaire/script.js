document.getElementById("startButton").addEventListener("click", startAnimation);

function startAnimation() {
    document.getElementById("startButton").style.display = "none";
    document.getElementById("message").style.display = "block";

    const song = document.getElementById("song");
    song.play().catch(error => {
        console.log("La lecture de la musique a été bloquée par le navigateur :", error);
    }); // Essayer de démarrer la musique

    createBalloons();
    createHearts();

    // Afficher le prénom après 5 secondes
    setTimeout(() => {
        document.getElementById("name").style.display = "block";

        // Masquer le prénom et démarrer l'animation de la boîte
        setTimeout(() => {
            document.getElementById("name").style.display = "none";
            startBoxAnimation();
        }, 3000);
    }, 5000);
}

function startBoxAnimation() {
    const box = document.getElementById("box");
    box.style.display = "block"; // Afficher la boîte

    // Laisser la boîte tourner pendant 5 secondes
    setTimeout(() => {
        box.style.animation = 'none'; // Arrêter l'animation de rotation
        box.style.backgroundColor = 'transparent'; // Rendre la boîte transparente
        createHeartAndWishes(); // Démarrer l'animation du cœur et des vœux
    }, 5000);
}

function createHeartAndWishes() {
    const wishes = document.getElementById("wishes");
    wishes.classList.remove("hidden");
    wishes.style.display = "block"; // Afficher le texte

    // Afficher les cœurs
    const heart = document.createElement("div");
    heart.classList.add("big-heart");
    document.body.appendChild(heart);

    setTimeout(() => {
        heart.remove(); // Enlever le grand cœur après un certain temps
        explodeHearts(); // Démarrer l'explosion des cœurs
    }, 2000); // Afficher le grand cœur pendant 2 secondes
}

function explodeHearts() {
    for (let i = 0; i < 100; i++) {
        const smallHeart = document.createElement("div");
        smallHeart.classList.add("small-heart");
        document.body.appendChild(smallHeart);

        // Déterminer une direction aléatoire pour chaque petit cœur
        const angle = Math.random() * 2 * Math.PI; // Angle aléatoire
        const distance = Math.random() * 200 + 50; // Distance aléatoire

        // Définir la position de chaque petit cœur
        smallHeart.style.left = `${50 + distance * Math.cos(angle)}vw`;
        smallHeart.style.top = `${50 + distance * Math.sin(angle)}vh`;
        
        // Enlever les petits cœurs après un certain temps
        setTimeout(() => {
            smallHeart.remove();
        }, 2000); // Les petits cœurs disparaissent après 2 secondes
    }
}

function createBalloons() {
    for (let i = 0; i < 10; i++) {
        const balloon = document.createElement("div");
        balloon.classList.add("balloon");
        balloon.style.left = Math.random() * 100 + "vw";
        balloon.style.animationDuration = 4 + Math.random() * 4 + "s";
        document.body.appendChild(balloon);

        balloon.addEventListener("animationend", () => {
            balloon.remove();
        });
    }
}

function createHearts() {
    for (let i = 0; i < 10; i++) {
        const heart = document.createElement("div");
        heart.classList.add("heart");
        heart.style.left = Math.random() * 100 + "vw";
        heart.style.animationDuration = 3 + Math.random() * 3 + "s";
        document.body.appendChild(heart);

        heart.addEventListener("animationend", () => {
            heart.remove();
        });
    }
}
